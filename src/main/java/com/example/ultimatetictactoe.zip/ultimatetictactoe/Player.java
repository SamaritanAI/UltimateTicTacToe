package com.example.ultimatetictactoe;

public enum Player {
    X, O
}
